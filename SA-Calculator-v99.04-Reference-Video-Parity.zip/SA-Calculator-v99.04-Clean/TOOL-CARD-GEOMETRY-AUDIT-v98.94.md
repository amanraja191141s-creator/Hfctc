# SA Calculator v98.94 — All-tool card geometry micro-audit

## Requested geometry

- Target card width: **430 CSS px maximum**.
- Target card height: **114 CSS px exactly**.
- `box-sizing: border-box` is enforced so padding and borders remain inside the 114px boundary.
- On screens narrower than 430 CSS px, cards use the available screen width rather than causing horizontal overflow.

## Coverage

The geometry contract is applied to visible card surfaces in all 19 tool screens:

1. Currency Converter
2. Unit Converter
3. Discount Calculator
4. Percentage Calculator
5. GST Calculator
6. Age Calculator
7. Body Metrics
8. Date Calculator
9. Fuel Cost
10. Fuel Efficiency
11. Grade Average
12. Hex Converter
13. Loan Calculator
14. Salary Calculator
15. Savings Calculator
16. SIP Calculator
17. Tip Calculator
18. Unit Price
19. World Time

The source contains 68 statically declared card surfaces across the 19 tools under the audited card selectors. Dynamic date reminder cards, world-clock rows and GPA course rows receive the same 430px/114px rule when created.

## Card families covered

- `.calc-card` and `.result-card`
- `.reference-form-card` and `.reference-result-card`
- `.bmi-reference-field-card`, GST form/result cards and GPA result cards
- Loan form/result cards and Savings field cards
- Currency reference fields and Discount result/input rows
- Percentage input rows and Hex base rows
- Date difference/result/event cards
- World-time hero/base/clock cards
- Unit-price and reference-unit cards
- Dynamically generated GPA course rows

## Layout and interaction safeguards

- Dense forms and multi-line results retain their existing content and use contained vertical scrolling inside the fixed-height card. This avoids hiding controls or clipping result rows merely to meet the requested boundary.
- Long numeric fields keep their own horizontal scroll/caret behaviour; the card itself clips horizontal overflow to prevent viewport-level sideways scrolling.
- GST rate card retains its two-column icon/field grid; its label, rate input and preset controls are not converted to a plain block layout.
- Percentage tool transparent wrapper remains a wrapper; its visible input rows receive the card dimensions.
- Age screen's transparent wrapper remains excluded; its DOB and Today surfaces receive the dimensions.
- World-time cards are placed in a single centered column so each can reach the 430px maximum.
- Tool launcher buttons, keypad keys, modal dialogs, settings cards, and decorative wrappers are intentionally excluded: they are not calculator-tool content cards and forcing them to 114px would break their separate interaction layouts.

## Per-tool static card surface counts

| Tool | Count |
|---|---:|
| Currency Converter | 2 |
| Unit Converter | 3 |
| Discount Calculator | 7 |
| Percentage Calculator | 8 |
| GST Calculator | 6 |
| Age Calculator | 3 |
| Body Metrics | 3 |
| Date Calculator | 4 |
| Fuel Cost | 2 |
| Fuel Efficiency | 2 |
| Grade Average | 2 |
| Hex Converter | 4 |
| Loan Calculator | 4 |
| Salary Calculator | 2 |
| Savings Calculator | 7 |
| SIP Calculator | 3 |
| Tip Calculator | 2 |
| Unit Price | 3 |
| World Time | 1 |
| **Total** | **68** |

Dynamic date, world-clock and GPA rows are additional runtime-created surfaces and are covered by the CSS contract.

## Validation scope and limitations

- Regression suite: 161 tests passed, 0 failed.
- All 19 tool screen IDs present; HTML has 316 unique IDs and no duplicate IDs.
- CSS source syntax and brace balance checked; JavaScript syntax checks passed.
- All 21 YAML files in the project parsed and were byte-identical; the v98.94 standalone Android YAML is also included in the release archive and checked below.
- Android web bundle preparation verified 13 required assets; 8 root/`www` web assets were byte-identical.
- ZIP archive integrity verified.

No physical Android-device visual/touch test, screenshot pixel measurement, APK build/signing, or remote GitHub Actions run was performed in this environment. The CSS target is measured in CSS pixels, not raw device pixels; Android density scaling can make the physical-pixel measurement differ.
