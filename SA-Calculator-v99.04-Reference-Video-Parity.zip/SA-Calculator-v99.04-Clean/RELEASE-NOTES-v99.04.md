# SA Calculator v99.04 — Reference-video parity

- Audited the 2026-11-24 Android screen recording (720×1560, 59.59 seconds).
- Reworked the mobile tools dashboard to a three-column categorized card grid.
- Applied the charcoal/blue reference palette and outlined active/inactive input treatment across tool screens.
- Tuned the shared numeric keypad to the reference 4×4 dock proportions and retained converter-specific actions.
- Updated GST labels and mode controls; the shared equals key is the commit action.
- Replaced Loan tenure picker entry with numeric tenure plus Months/Years.
- Replaced Saving legacy six-field UI with Saving Goal, Rate of Interest and Saving Period.
- Updated Salary labels and initial empty Tax rate.
- Currency keypad action now swaps the currency pair.
- Unit Converter now opens a category chooser first, then the selected category workspace.
- Discount and Percentage use the shared equals action rather than visible Calculate buttons.
- Preserved existing calculator formulas where the recording does not show enough evidence to safely redefine them.
- Added reference-video parity regression coverage.
- Release version: `1.99.18-v99.04`; Android versionCode: `1099133`.
