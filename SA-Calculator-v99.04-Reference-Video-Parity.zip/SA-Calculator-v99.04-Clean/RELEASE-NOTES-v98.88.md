# SA Calculator v98.88

Fixes a GST screen layout regression found by comparing two 709 × 1536 screenshots. Restores the amount placeholder when the inline caret is active, removes duplicated GST rate placeholder rendering, stabilizes the GST rate field and quick-rate grid, and keeps mode/state controls in separate normal-flow rows. Existing GST calculations and keypad action handlers are preserved.

Release identity: `1.99.02-v98.88` (Android versionCode `1099108`).
