# SA Calculator v98.93 — Release Notes

- Extended shared numeric input initialization across all 19 tool screens.
- Standardized editable custom field accessibility semantics and decimal input mode.
- Synchronized empty-state placeholder flags on initial load and after restoring saved inputs.
- Generalized single-caret cleanup when switching between any custom numeric fields.
- Added a shared placeholder layer that remains correct when the app-managed caret is present.
- Disabled Android native selection callouts for custom numeric fields while retaining app-managed caret placement.
- Preserved each tool's own calculation formulas, date pickers, unit selectors, specialized Hex keyboard and loan tenure picker.
- Added 6 all-tools field-contract regression checks; full suite: 154 passing tests.
