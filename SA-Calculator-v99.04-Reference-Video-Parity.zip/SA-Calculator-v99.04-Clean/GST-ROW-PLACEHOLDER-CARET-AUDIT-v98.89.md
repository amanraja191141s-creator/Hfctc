# SA Calculator v98.90 — GST Rate Row, Placeholder and Caret Audit

## Source basis
- Latest supplied recording: `Screenrecording_20261124_133855.mp4` (24.285 seconds, 720×1560 portrait).
- Base source archive: `SA-Calculator-v98.88-GST-Placeholder-Fixed.zip`.
- The archive's internal app folder was named `SA-Calculator-v98.86`; its package/release identity was v98.88.

## Reproduced defects in the recording
1. Amount field displayed a populated number and the `Enter amount` placeholder at the same time (for example, the frame around 14 seconds).
2. GST Rate field displayed `9%` and `Add rate` simultaneously.
3. The 5% and 18% quick-rate controls appeared below the Add rate value instead of in the same entry row.
4. The rate-card structure used a separate card-level grid for the quick-rate controls. Several accumulated CSS overrides alternated between `display:contents`, a three-column card grid and different row assignments, which caused the rate controls to drift.
5. Long input values had no dedicated horizontal scroll viewport, so the caret/value could extend beyond the intended visible input area.

## Root cause
The placeholder rule used `:has(> .input-cursor:only-child)`. CSS `:only-child` counts element siblings, not text nodes. The caret can therefore be the only element child even when numeric text nodes are also present, causing the placeholder pseudo-element to remain visible after typing. The rate card's quick-rate buttons were also laid out as a separate card-level grid item instead of as siblings of the rate input inside one flex entry row.

## Changes in v98.90
- Rebuilt GST Rate card markup into an explicit icon + label + entry-row structure.
- The rate entry row now contains the editable rate field and the 5% / 18% quick-rate buttons in one horizontal flex row.
- Amount and rate cards use the same fixed outer height and responsive width.
- Replaced the ambiguous `:only-child` placeholder logic with an explicit `.is-empty` state maintained by the input renderer.
- Initial empty fields carry `.is-empty`, so placeholders are visible before the first tap.
- The first entered character clears the empty state; clearing the field restores the placeholder.
- A single active GST field retains a caret. Switching fields removes the previous GST caret; closing the keypad removes the transient caret while preserving the caret index.
- Long GST values use a horizontal overflow viewport. The renderer scrolls only the active field enough to keep the insertion point visible.
- The caret index remains expressed in raw numeric characters, then maps into the formatted display string while skipping commas, currency markers, whitespace and percent suffixes.
- Quick-rate selection displays the selected percentage and positions the caret before the `%` suffix.
- GST arithmetic, rate limits, mode/state choices, result lifecycle and the shared keypad actions are preserved.

## Release identity
- App version: `1.99.06-v98.92`
- Android versionCode: `1099111`
- Service-worker cache: `sa-calculator-v98-92-gst-rate-position-placeholder-preset-v9892`

## Verification
- Automated regression suite: 133/133 passed.
- JavaScript syntax checks: passed.
- Android web preparation: 13 required assets verified.
- Root and `www/` canonical assets: 8/8 byte-identical.
- YAML: all shipped workflow copies parse and are byte-identical.
- Explicit npm release test entry points: 24/24 exist.
- ZIP archive integrity: verified in the release build.

## Validation boundary
A real Android device test (touch coordinates, keyboard/caret scroll, rotation, safe areas and sustained performance) and a remote GitHub Actions APK build were not run in this environment. Automated checks do not establish zero bugs or guarantee lag-free behavior on every device.
