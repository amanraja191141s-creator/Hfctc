# Build verification — SA Calculator v99.04

## Release identity
- App version: `1.99.18-v99.04`
- Android versionCode: `1099133`
- Service-worker cache: `sa-calculator-v99-04-reference-video-parity-v9904`

## Verified
- Exact requested tool count: 12
- Exact retained IDs: `salestax`, `loan`, `savings`, `salary`, `tip`, `sip`, `currencies`, `discount`, `percent`, `units`, `agecalc`, `bodymetrics`
- Reference-video UI regression tests: passed
- `node --check assets/js/app.js`: passed
- `npm run test:release`: 51 tests / 51 passed
- CSS parse: passed, no syntax errors
- HTML parse: passed, no duplicate IDs
- `npm run build:web`: passed
- Root / `www` HTML, JS, CSS, manifest and service worker parity: passed
- Android workflow YAML parse: passed
- Standalone YAML and `.github/workflows/main.yml`: byte-identical
- ZIP integrity: passed

## Key implementation points
- Three-column mobile tool launcher and video-matched charcoal theme.
- Shared 4×4 docked numeric keypad with converter-specific swap actions and commit-gated result panels.
- GST mode/rate/place controls and equals-key commit.
- Numeric Loan Tenure with Months/Years selector.
- Three-field Saving Goal flow with Months/Years selector.
- Salary labels, Currency swap action, Unit category-first navigation.
- Discount and Percentage use equals-key commit.
- Existing calculator engines and all 12 requested tool destinations preserved.

## Not claimed
- No physical Android handset test was performed.
- No GitHub Actions run or APK artifact is included.
- Pixel-perfect parity across all screen densities and user font scales is not guaranteed.
- Automated tests cannot prove zero bugs or zero lag on every Android device.
