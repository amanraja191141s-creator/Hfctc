import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const workflow=fs.readFileSync('.github/workflows/main.yml','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
test('npm cache setup remains lockfile-independent and precedes install',()=>{
 assert.equal(fs.existsSync('package-lock.json'),false);
 assert.ok(workflow.includes('uses: actions/cache@v6'));
 assert.ok(workflow.indexOf('name: Cache npm downloads')<workflow.indexOf('name: Install npm dependencies'));
 assert.ok(workflow.includes("node-version: '24'"));
});
test('v99.04 release identity and cache namespace are synchronized',()=>{
 const v='1.99.18-v99.04'; assert.equal(pkg.version,v); assert.equal(pkg.androidVersionCode,1099133);
 assert.ok(fs.readFileSync('index.html','utf8').includes(v));
 assert.ok(fs.readFileSync('assets/js/app.js','utf8').includes(`const APP_VERSION = '${v}'`));
 assert.equal(JSON.parse(fs.readFileSync('manifest.webmanifest','utf8')).version,v);
 const cache=fs.readFileSync('service-worker.js','utf8').match(/^const CACHE='([^']+)'/m)?.[1];
 assert.equal(cache,'sa-calculator-v99-04-reference-video-parity-v9904');
 assert.ok(workflow.includes("const expectedCache='sa-calculator-v99-04-reference-video-parity-v9904'"));
});
test('release test entry points are explicit, present, and mirrored in CI',()=>{
 const cmd=pkg.scripts['test:release']; const files=[...cmd.matchAll(/(?:^|\s)(tests\/[^\s]+)/g)].map(x=>x[1]);
 assert.ok(files.length>=7); for(const f of files) assert.ok(fs.existsSync(f),`missing ${f}`);
 const a=workflow.indexOf('for(const f of ['); const b=workflow.indexOf(']) {',a);
 const required=[...workflow.slice(a,b).matchAll(/'(tests\/[^']+\.test\.(?:mjs|js))'/g)].map(x=>x[1]);
 assert.ok(required.length>=7); for(const f of required) assert.ok(files.includes(f),`CI test missing from npm suite: ${f}`);
});
test('Android workflow version and web bundle checks target the new release',()=>{
 assert.ok(workflow.includes("SA_EXPECTED_VERSION: '1.99.18-v99.04'"));
 assert.ok(workflow.includes('if(p.androidVersionCode!==1099133)'));
 assert.ok(workflow.includes("if(!fs.readFileSync('www/index.html','utf8').includes('1.99.18-v99.04'))"));
});
test('standalone Android workflow is byte-identical to repository workflow',()=>{
 assert.equal(fs.readFileSync('sa-calculator-v99.04-android.yml','utf8'),workflow);
});
