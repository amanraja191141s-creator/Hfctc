import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const html=fs.readFileSync('index.html','utf8');
const js=fs.readFileSync('assets/js/app.js','utf8');
const css=fs.readFileSync('assets/css/tool-reference-ui.css','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));

test('v98.85 tool screens and launcher use the unified white workspace',()=>{
  assert.match(css,/#screen-tools\s*\{[\s\S]*background:#f3f4f6/);
  assert.match(css,/#screen-viewport #screen-currencies[\s\S]*background:#f3f4f6/);
  assert.match(css,/#tool-keypad-dock,[\s\S]*background:#f3f4f6/);
});

test('unit category chooser is inline and legacy duplicate category sheet is hidden',()=>{
  assert.match(css,/unit-category-state,[\s\S]*display:none !important/);
  assert.match(css,/unit-category-chooser\s*\{[\s\S]*position:relative !important/);
  assert.match(css,/#screen-viewport #screen-units #btn-unit-swap\s*\{\s*display:none !important/);
});

test('currency keypad does not expose redundant swap action',()=>{
  assert.match(js,/const isUnitSwapTool = STATE\.currentScreen === 'units'/);
  assert.match(js,/actionKey\.textContent = isUnitSwapTool \? '⇅' : '='/);
  assert.match(js,/if \(STATE\.currentScreen === 'currencies'\) \{\s*recalculateCurrentScreen\(\)/);
});

test('numeric tool keypad inserts and deletes at tapped caret position',()=>{
  assert.match(js,/function renderToolInputValue\(target, displayValue, caretIndex\)/);
  assert.match(js,/document\.caretRangeFromPoint\?\./);
  assert.match(js,/field\.dataset\.caretIndex = String\(/);
  assert.match(js,/candidate = val\.slice\(0, caret\) \+ inserted \+ val\.slice\(caret\)/);
  assert.match(js,/if \(caret > 0\) val = val\.slice\(0, caret - 1\) \+ val\.slice\(caret\)/);
});

test('tool input caret remains a real inline element after formatting',()=>{
  assert.match(js,/textSpan\.replaceChildren\([\s\S]*cursor[\s\S]*value\.slice\(displayIndex\)/);
  assert.match(css,/\.input-val-box \.input-cursor/);
});

test('release identity is v98.85',()=>{
  assert.equal(pkg.version,'1.99.15-v99.01');
  assert.equal(pkg.androidVersionCode,1099130);
  assert.ok(html.includes('1.99.15-v99.01'));
});
