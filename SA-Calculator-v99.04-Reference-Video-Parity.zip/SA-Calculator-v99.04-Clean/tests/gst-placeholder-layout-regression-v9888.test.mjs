import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const css=fs.readFileSync(path.join(root,'assets/css/tool-reference-ui.css'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
test('GST amount and rate each have one input value span and one placeholder source',()=>{
  for (const id of ['tax-orig','tax-rate']) {
    const re=new RegExp(`<div class="input-val-box[^\"]*" id="${id}"[^>]*><span class="input-text is-empty" data-placeholder="[^"]+"><\\/span><\\/div>`);
    assert.match(html,re,`${id} markup must keep one text span`);
  }
  assert.match(css,/#tax-orig\.input-val-box\[data-placeholder\]::before,[\s\S]*?#tax-rate\.input-val-box\[data-placeholder\]::before\s*\{\s*content:none/);
  assert.match(css,/#tax-orig \.input-text:has\(> \.input-cursor:only-child\)::after,[\s\S]*?#tax-rate \.input-text:has\(> \.input-cursor:only-child\)::after/);
});
test('GST rate field is an explicit grid, not display:contents',()=>{
  const final=css.slice(css.lastIndexOf('v98.88 — authoritative GST form layout'));
  assert.match(final,/\.gst-rate-field\s*\{[\s\S]*?display:grid !important/);
  assert.doesNotMatch(final,/\.gst-rate-field\s*\{[^}]*display:contents/);
  assert.match(final,/\.gst-quick-rates\s*\{[\s\S]*?grid-column:2 !important/);
});
test('GST controls remain separate normal-flow rows and result is scroll-friendly',()=>{
  const final=css.slice(css.lastIndexOf('v98.88 — authoritative GST form layout'));
  assert.match(final,/\.gst-mode-row,[\s\S]*?\.gst-place-row\s*\{[\s\S]*?position:static !important/);
  assert.match(final,/\.tool-result-content\s*\{[\s\S]*?height:auto !important/);
});
test('release identity and service worker cache namespace are synchronized',()=>{
  assert.equal(pkg.version,'1.99.15-v99.01');
  assert.equal(pkg.androidVersionCode,1099130);
  assert.match(fs.readFileSync(path.join(root,'manifest.webmanifest'),'utf8'),/1\.99\.15-v99\.01/);
  assert.match(fs.readFileSync(path.join(root,'service-worker.js'),'utf8'),/sa-calculator-v99-01-card-css-purged-v9901/);
});
