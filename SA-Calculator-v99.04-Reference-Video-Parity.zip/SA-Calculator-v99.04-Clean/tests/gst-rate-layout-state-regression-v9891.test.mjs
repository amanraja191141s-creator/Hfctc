import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
test('GST rate label is above the input and preset row',()=>{
 const html=read('index.html'); const css=read('assets/css/tool-reference-ui.css');
 assert.match(html,/<span class="gst-rate-label">GST Rate\(%\)<\/span>/);
 assert.match(html,/id="tax-rate"[\s\S]*?data-placeholder="Add rate"/);
 assert.match(html,/data-gst-rate="5"/); assert.match(html,/data-gst-rate="18"/);
 assert.match(css,/\.gst-rate-label[\s\S]*?text-align:left !important/);
 assert.match(css,/\.gst-rate-entry-row[\s\S]*?flex-flow:row nowrap/);
});
test('Different State hides split-tax rows and shows IGST row',()=>{
 const css=read('assets/css/tool-reference-ui.css'); const js=read('assets/js/app.js');
 assert.match(css,/\.gst-video-result-row\[hidden\][\s\S]*?display:none !important/);
 assert.match(js,/const place = button\.dataset\.gstPlace === 'different' \? 'different' : 'same'/);
 assert.match(js,/toggleAttribute\('hidden', !same\)/);
 assert.match(js,/toggleAttribute\('hidden', same\)/);
});
test('GST rate and amount keep custom caret/placeholder implementation',()=>{
 const css=read('assets/css/tool-reference-ui.css'); const js=read('assets/js/app.js');
 assert.match(css,/#tax-orig\.is-empty::after/); assert.match(css,/#tax-rate\.is-empty::after/);
 assert.match(css,/input-cursor/); assert.match(js,/renderToolInputValue\(target, `\$\{value\}%`/);
});
test('Release identity is v98.91',()=>{
 const pkg=JSON.parse(read('package.json'));
 assert.equal(pkg.version,'1.99.15-v99.01'); assert.equal(pkg.androidVersionCode,1099130);
});
