# Tools removal audit — v99.02

## Requested scope
All tool surfaces (including Currency Converter) are removed. The shared numeric tool keypad is retained. The primary calculator and its scientific keypad, history, settings, theme, localization shell, and app navigation containers remain.

## Removed from the rendered app
- All 19 individual tool workspaces: currency, units, discount, percentage, GST, age, BMI, date, fuel cost, fuel efficiency, grade average, hexadecimal, loan, salary, savings, SIP, tip, unit price, and world time.
- Tool launcher cards, tool categories/search UI, and favorites tool list.
- Dedicated tool-reference stylesheet link.
- Tool initialization calls, currency-rate refresh startup, unit initialization, and world-time polling startup.

## Retained
- The single shared `#tool-keypad-dock` and all 15 keys remain in source. It stays hidden until a numeric tool field is focused; since all tool fields are removed, it is retained but not automatically displayed.
- Main calculator keypad and scientific keypad.
- Existing calculator core, history, settings, theme, and localization.
- Empty screen containers with stable IDs so app navigation does not fail on missing targets.

## Scope boundary
Legacy tool function definitions and the historical tool stylesheet file remain in the source archive but are not loaded/initialized by the app. They are retained to avoid unsafe deletion of shared helpers before a separate dependency-aware source refactor. No claim is made that every legacy tool-related byte has been purged.

## Verification
See `BUILD-VERIFICATION-v99.02.md`. Automated checks cover structure, retained keypad, JavaScript syntax, core calculator regression tests, and generated web-bundle synchronization. Physical Android device testing is still required.
