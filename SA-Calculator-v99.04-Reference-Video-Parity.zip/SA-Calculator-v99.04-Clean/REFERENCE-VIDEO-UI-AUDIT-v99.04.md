# SA Calculator v99.04 — Reference-video micro-level UI/UX audit

## Source inspected
- User recording: `Screenrecording_20261124_185616.mp4`
- Duration: 59.59 seconds
- Capture: 720 × 1560 px, approximately 41.92 fps
- The recording was sampled throughout the full clip, with detailed checks of the tool dashboard, GST, Loan, Saving, Salary, SIP, Currency, Discount, and Unit Converter screens.
- The v99.03 source ZIP was unpacked and inspected before editing.

## Reference design system

### Global geometry and visual language
- Neutral charcoal tool canvas (approximately `#3d3d3d`), not a blue-black surface.
- White screen title and numeric values; muted gray inactive text.
- Bright blue focus/selection state (approximately `#087bff`).
- Tool inputs are broad, full-width outlined fields with approximately 11 px corner radius and a 2 px outline.
- Reference capture field height is approximately 88 CSS px at the 1.25 device scale used for the 720 px capture.
- Horizontal field inset is approximately 20 CSS px.
- Labels float across the upper field border while the field is active; inactive fields show their placeholder inside the outline.
- Tool page header has a left back arrow and a compact title; the content begins below it.
- Tool pages share one bottom-docked numeric keypad rather than opening a native keyboard.

### Tool dashboard
- Three cards per row on a 720 px-wide Android capture.
- Group headings: `Finance & Money`, `Math & General Utilities`, and `Health`.
- Tool card icon is centered above its label; card surface is darker charcoal than the page.
- Dashboard order is the requested 12 tools: GST/VAT, Loan, Saving, Salary, Tip, SIP, Currency, Discount, Percentage, Unit, Age, BMI.
- The recording includes an ad placement after the first six finance cards. This release does not fabricate an ad or insert a placeholder ad card; ad delivery remains outside the calculator's tool navigation.

### Shared keypad
- Docked at the bottom and sized to approximately 48.2% of the captured viewport height.
- Four columns and four rows, with circular numeric keys.
- Number keys use a darker charcoal fill; AC and delete use a lighter gray fill.
- The calculate key is blue and spans the last two rows in the fourth column.
- Currency uses that tall blue key as a pair-swap action.
- Unit Converter uses the in-form circular swap control and reserves the keypad's fourth column for tall AC and delete controls; the equals action is not shown.
- The scroll area reserves space below the active form so lower controls can still be reached while the keypad is open. Result panels stay hidden until equals commits a result and are hidden again when a numeric field is edited.

## Screen-by-screen observations and changes

### 1. GST Calculator
Reference fields and controls:
- Original Price
- Add GST / Remove GST
- Add GST Rate, with 5% and 18% quick-rate chips
- In-State / Out-of-State
- GST breakdown rows after equals

Changes:
- Aligned the visible labels and mode names to the recording.
- Kept the existing tax calculation engine and maps Add GST to exclusive calculation and Remove GST to inclusive extraction.
- Kept the 5% and 18% presets and state-dependent SGST/CGST versus IGST breakdown.
- Hid the redundant standalone Calculate button; the shared equals key commits the result.
- Added active floating captions and inline empty-field hints.

### 2. Loan Calculator
Reference fields:
- Loan Amount
- Rate of Interest
- Loan Tenure
- Months / Years radio selector
- Result rows after equals

Changes:
- Replaced the old modal tenure wheel entry with the numeric tenure field and Months/Years selector shown in the recording.
- Updated the loan period conversion: years are converted to 12-month periods; months remain month counts.
- Preserved the existing EMI/amortization calculation and result rows.
- Changing the tenure unit invalidates the previously committed result.

### 3. Saving Calculator
Reference fields:
- Saving Goal
- Rate of Interest
- Saving Period
- Months / Years radio selector

Changes:
- Replaced the six-field legacy presentation with the three-field video layout.
- Hid legacy monthly-contribution, compounding-frequency and tax controls without deleting shared calculation helpers.
- Period entry now supports either months or years and converts to the existing savings projection's year basis.
- The previous savings projection is retained. The recording does not show a completed savings result, so no unsupported target-contribution formula was invented.

### 4. Salary Calculator
- Visible fields now read `Salary amount` and `Tax rate`.
- The initial tax-rate field is empty, as in the recording.
- Existing take-home and annual take-home calculation remains unchanged.

### 5. Tip Calculator
- Preserves Bill Amount, Rate of Tip, and Number of Person.
- Shared keypad and equals result lifecycle retained.
- Existing per-person amount, total tip, per-person tip, and total bill calculations remain unchanged.

### 6. SIP Calculator
- Preserves the two tabs: SIP Calculator and SIP Delay Cost.
- Preserves monthly SIP amount, investment period, expected return rate, and delay months in delay mode.
- Existing SIP future-value and delay-cost calculation remains unchanged.
- Tab selection invalidates stale results and returns focus to the first field in the selected mode.

### 7. Currency Calculator
- Preserves two stacked source/converted amount panels and right-side ISO currency selectors.
- Source amount remains editable; converted amount remains read-only and updates live.
- Tall keypad action now swaps the actual source/target currency pair through the existing swap handler.
- The source video shows SAR → EUR as one selected pair; the app keeps user-selectable currency codes rather than hard-locking that pair.

### 8. Discount Calculator
- Visible inputs now match the recording: Original Amount and Discount Rate(%).
- The legacy added-tax compatibility field is hidden and defaults to zero.
- Standalone Calculate button is hidden; equals commits the calculation.
- Existing discount amount, amount saved, and final-price calculations remain unchanged.

### 9. Percentage Calculator
- Existing Percentage and Percent Change modes are preserved.
- Redundant visible Calculate action is hidden so the shared equals key is the action.
- Existing percentage formulas are unchanged.

### 10. Unit Converter
- Category selection is now a distinct first step; the conversion workspace starts hidden to prevent two screens being shown together.
- Selecting a category opens its conversion workspace and title (for example, `Weight Calculator`).
- Toolbar back returns from the category workspace to the category chooser; a second back returns to the parent tools surface.
- Source and target values remain paired with their selectors; the circular swap control exchanges the selected units.
- Unit keypad uses tall AC/delete controls and no equals key.

### 11. Age Calculator
- The recording does not show this screen.
- Existing native date-of-birth picker, Today value, Calculate action, and age/next-birthday result structure are preserved.
- It is not forced onto the numeric keypad.

### 12. BMI Calculator
- The recording does not show this screen.
- Existing Weight and Height entry, kg/lbs and cm/in controls, BMI range display, and validation are preserved.
- Shared keypad and result lifecycle remain available.

## Action-time behavior
- Numeric tool fields use the shared docked keypad.
- Editing a committed calculation invalidates stale result state.
- Equals commits numeric tool calculations and closes the keypad; Currency and Unit remain converter-specific swap actions.
- Unit category selection and currency/unit pair swapping retain their existing calculation engines.
- The keypad scroll reserve was increased and field content remains scrollable while the dock is open.

## Validation performed
- `node --check assets/js/app.js`: passed.
- Release regression suite: 51/51 passed.
- CSS parsed with tinycss2: no syntax errors.
- HTML parsed; no duplicate element IDs.
- Tool launcher registry: exactly 12 requested tool IDs.
- Root and generated `www/` HTML, JS, CSS, manifest and service worker are byte-identical after web build.
- Android workflow YAML parsed successfully.
- Standalone Android YAML is byte-identical to `.github/workflows/main.yml`.
- ZIP archive integrity checked after packaging.

## Validation boundary
- A real Android device was not available for touch, font-scale, animation, FPS, memory, or battery testing.
- Headless Chromium rendering was blocked by the execution environment, so no pixel-diff screenshot claim is made.
- GitHub Actions has not been run here and no APK is included.
- Exchange rates still depend on the configured provider/network.
- The video does not reveal the exact formula behind the Saving Goal field or the detailed Age/BMI screens; the existing savings projection and Age/BMI calculation engines were preserved rather than guessing new formulas.
